#include <iostream>

using namespace std;

void grow( int );
void rgrow( int& );
void pgrow( int* );
    
int main() {
    int age = 19;

    cout << "age is " << age << endl;
    grow( age );
    cout << "after grow, age is " << age << endl;

    rgrow( age );
    cout << "after rgrow, age is " << age << endl;

    pgrow( &age );
    cout << "after pgrow, age is " << age << endl;

    return 0;   
}

void grow( int a ) {
    a++;
}

void rgrow( int& a ) {
    a++;
}

void pgrow( int* p ) {
    (*p)++;
}
