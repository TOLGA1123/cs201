#include <iostream>

using namespace std;

void displayArray( const double a[], const int size ) {
    for (size_t i = 0; i < size; i++)
    {
        cout << a[i] << " ";
    }
    cout << endl;
}

// seperate block will be allocatedshallow
void deep_copy1( double* arr, const int size, double*& output ) {
    output = new double[size];
    for (size_t i = 0; i < size; i++)
    {
        output[i] = arr[i];
    }    
}

void shallow_copy2( double* arr, const int size, double** output ) {
    *output = arr;
}

int main(int argc, char const *argv[])
{
    double d[] = {2.4, 5.3, 7.2};
    double *D;
    
    displayArray(d, 3);
    deep_copy1( d, 3, D );
    

    d[1] = -1;
    d[2] = -2;

    displayArray(D, 3); 
    displayArray(d, 3);

    return 0;
}

