// examples for new and delete operators
#include <iostream>
using namespace std;

class Test {
public:
    static int counter ;
    Test(); // default constructor
    Test(int t);     
    ~Test();  // destructor -- is called when an object is destroyed
};

int Test::counter ;

Test::Test() {
    cout << "in default constructor... counter: " << ++counter << "\n";
}

Test::Test(int t) {
  cout << "in constructor... t: " << t << " counter: " << ++counter << "\n";
}

Test::~Test() {
    cout << "in destructor... counter: " << counter-- << "\n";
}


int main() 
{
  Test* p;
 // Test obj;

  cout << "will allocate one (unnamed) Test object...\n";
  p = new Test;  
  cout << "p: " << p << endl;
  cout << "will deallocate the Test object pointed by the pointer p...\n";
  delete p;

//   p = new Test(11);
//   delete p;

  cout << "will allocate a dynamic array of 10 Test objects...\n";
  int x = 10;
  // cin >> x;
  p = new Test[x];  
  cout << "will deallocate a dynamic array of 10 Test objects...\n";
  delete [] p;

//   Test **pp = new Test *[10];
//   for (int i=0; i < 10; ++i)
//     pp[i] = new Test(i);

//   for (int i=0; i < 10; ++i)
//     delete pp[i];
//   delete [] pp;
}
