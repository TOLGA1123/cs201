#include <iostream>

using namespace std;

int incorrectUse( int A[] ) {
    int size = sizeof(A) / sizeof(int);
    return size;
}
int main() {
    int A[] = { 1, 2, 3, 4, 5} ;
    int* B = new int[ 5 ];
    cout << sizeof(A) / sizeof(int) << endl;
    cout << sizeof(B) / sizeof(int) << endl;
    cout << incorrectUse(A) << endl;
    cout << incorrectUse(B) << endl;
    return 0;
}
