#include <iostream>

using namespace std;

int main() {
   // char array declaration using an
   // initializer list, equivalent to
   // char a[] = {'H', 'i', '\0'};
   char a[] = "Hi";

   cout << "sizeof of a: " << sizeof(a) / sizeof(char) << endl;
   
   cout << a << endl;
   a[ 1 ] = '\0';
   cout << a << endl;
   cin >> a;
   cout << a << endl;

   cout << "sizeof of a: " << sizeof(a) / sizeof(char) << endl;
   
   char *b = new char[ 10 ];
   cin >> b;
   cout << b << endl;
   delete[] b;
   return 0;
}
