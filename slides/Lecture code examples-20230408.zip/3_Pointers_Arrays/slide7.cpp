#include <iostream>

using namespace std;

int main() {
    
    int a, *b, **c;
    double x = 3.4, *y = &x; // y points to x
    b = &a;	// b points to a
    c = &b;	// c points to b
    a = 5;	// direct access to a
    **c = 20;	// indirect access to a
    cout << "a is " << a << endl;
    
    // through double dereferencing
    // Compile-time errors: RHS and LHS 
    // should be of the same type
    // b = y;		b is int* and y is double*
    // y = b;		y is double* and b is int*
    // y = &a;	y is double* and &a is int*
    // c = &a;	c is int** and &a is int*
    // *c = *b;	*c is int* and *b is int
    // Compile-time error: Arbitrary values 
    // cannot be assigned to pointers
    // b = 100000;
    // The following is a valid assignment
    // since *b is int and *y is double
    *b = *y;

    cout << "a is " << a << endl;
}
