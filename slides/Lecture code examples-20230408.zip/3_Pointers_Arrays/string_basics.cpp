/*
*  string class functions & operators examples
*
* Slide 41-43, 3_Pointers_Arrays
*/

#include <iostream>
#include <string>
using namespace std;

int main11() {

   string s1 = "happy", s2 = "birthday", s3;

   // subscript operator
   s1[0] = 'H';
   cout << "s1: " << s1 << endl;
   cout << "first char: " << s1[0] << endl;

   // string concatenation
   s1 += s2;
   cout << "s1: " << s1 << endl;
   cout << "s2: " << s2 << endl;

// string comparison
   // Outputs of the following statements
   // are given as comments. The program
   // uses 0 to display false and 1 to
   // display true.

   cout << ( s1 == s2 ) << endl;    // 0
   cout << ( s1 != s2 ) << endl;    // 1
   cout << ( s1 >  s2 ) << endl;    // 0
   cout << ( s1 >= s2 ) << endl;    // 0
   cout << ( s1 <  s2 ) << endl;    // 1
   cout << ( s1 <= s2 ) << endl;    // 1

 cout << "Enter your name: ";
   cin >> s3;
   // cin reads just one word (reads the
   // console input until it encounters a
   // white space). To read the entire line
   // use getline( cin, s3 ) global function

   // some member functions
   cout << "length of s2: " << s2.length();
   cout << "length of s2: " << s2.size();

   s1.append( " " + s3 );
   cout << "s1: " << s1 << endl;
   s1.insert( 5, " and happy " );
   cout << "s1: " << s1 << endl;
   s1.erase( 5, 4 );
   cout << "s1: " << s1 << endl;

   return 0;
}
