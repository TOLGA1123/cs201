// createArray_1 returns the array as a return value
double* createArray_1( ) {
   return new double [ 10 ];
}
// createArray_2 returns the array from the parameter list
// (using a reference parameter)
void createArray_2( double*& arr ) {
    arr = new double [ 10 ];
}
// createArray_3 returns the array from the parameter list
// (without using a reference parameter but simulating 
// pass-by-reference using a pointer)
void createArray_3( double** arr ) {
    *arr = new double [ 10 ];
}
// What is wrong with the following two functions?
// void incorrectCreateArray_1( double* arr ) {
//    arr = new double [ 10 ];
//}
// double* incorrectCreateArray_2( ) {
//    double arr[ 10 ];
//    return arr;
// }

int main() {
   double* D;
    
   D = createArray_1();
   delete [] D;
    
   createArray_2( D );
   delete [] D;
    
   createArray_3( &D );
   delete [] D;
    
   return 0;
}
