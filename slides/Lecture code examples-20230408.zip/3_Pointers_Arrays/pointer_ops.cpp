#include <iostream>

using namespace std;

int main() {
    int y = 2;
    int* yptr = nullptr;

    // *yptr = 4; // don't dereference before setting pointer, 

    cout << "yptr: " << yptr << endl;
    cout << "&y: " << &y << endl;

    //   bad  *yptr = y;
    yptr = &y;

    cout << "y: " << y << endl;
    *yptr = 10;
    (*yptr)++;
    cout << "y: " << y << endl;
    cout << "*yptr: " << *yptr << endl;

    // &y = 0x1000;

    return 0;    
}
