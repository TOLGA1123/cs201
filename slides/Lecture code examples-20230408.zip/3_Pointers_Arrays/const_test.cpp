#include <iostream>

using namespace std;

int main(int argc, char const *argv[])
{
    int data;
    int data2;
    const int*  ptr = &data;

    

    data = 2;

     cout << "ptr: " << ptr << endl;
    cout << "data: " << data << endl;   

   // *ptr = 4;

    ptr = &data2;

    cout << "ptr: " << ptr << endl;
    cout << "data: " << data << endl;

    return 0;
}
