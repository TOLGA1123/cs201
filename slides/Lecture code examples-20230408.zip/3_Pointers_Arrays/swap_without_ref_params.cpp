#include <iostream>

using namespace std;

class Student {
    public:
        int id;
};


// swaps two integers
void swapIntegers( int* i1, int* i2 ) {
    int t = *i1;
    *i1 = *i2;
    *i2 = t;
}

// swaps two integer pointers
void swapIntegerPointers( int** p1, int** p2 ) {
    int* t = *p1;
    *p1 = *p2;
    *p2 = t;
}

// swaps the id data members of two Student objects
// (assuming that the Student class has been 
// defined and it has a public id data member)
void swapStudentIds( Student* S1, Student* S2 ) {
    int old_id = (*S1).id;
    // (*S1).id = (*S2).id; // same as
    S1->id = S2->id;        // using arrow operator ->
    S2->id = old_id;
}

// swaps two Student objects
void swapStudentObjects( Student* S1, Student* S2 ) {
    Student temp = *S1;
    *S1 = *S2;
    *S2 = temp;
}

// swaps two Student object pointers
void swapStudentObjectPointers( Student** P1, Student** P2 ) {
    Student* t = *P1;
    *P1 = *P2;
    *P2 = t;
}


int main() {
  int a, b, *c = &a, *d = &b;
  Student S, R, *X = &S, *Y = &R;

  a = 2;
  b = 6;

  // // swap a and b
  // cout << "a: " << a << " b: " << b << endl; 
  // swapIntegers( &a, &b );
  // cout << "a: " << a << " b: " << b << endl; 

  // // swap c and d
  // cout << "c: " << c << " d: " << d << endl;
  // swapIntegerPointers( &c, &d );
  // cout << "c: " << c << " d: " << d << endl;


  // swap the ids of S and R
  // S.id = 5;
  // R.id = 10;
  // cout << "S.id: " << S.id << " R.id: " << R.id << endl;
  // swapStudentIds( &S, &R ); 
  // cout << "S.id: " << S.id << " R.id: " << R.id << endl;

   
  // swap S and R
  // S.id = 5;
  // R.id = 10;
  // cout << "S.id: " << S.id << " R.id: " << R.id << endl;
  // cout << "&S: " << &S << " &R: " << &R << endl;
  // swapStudentObjects( &S, &R );
  // cout << "S.id: " << S.id << " R.id: " << R.id << endl;
  // cout << "&S: " << &S << " &R: " << &R << endl;

  // swap X and Y
  // S.id = 5;
  // R.id = 10;
  // cout << "X: " << X << " Y: " << Y << endl; 
  // cout << "X->id: " << X->id << " Y->id: " << Y->id << endl; 
  // swapStudentObjectPointers( &X, &Y ); 
  // cout << "X: " << X << " Y: " << Y << endl; 
  // cout << "X->id: " << X->id << " Y->id: " << Y->id << endl; 
    
 return 0;
}
