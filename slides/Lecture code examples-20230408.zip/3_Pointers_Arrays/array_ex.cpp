#include <iostream>

using namespace std;

void displayArray( const int a[], const int size ) {
// void displayArray( int* a, const int size ) {    
    for (size_t i = 0; i < size; i++)
    {
        cout << a[i] << " ";
    }
    cout << endl;
    //    a[0] = -1;    // compile-time error
}

int main(int argc, char const *argv[])
{
    int A[4] = { 2, 4, 6, 8 };  // automatically allocated array
    int* B;

    cout << "A:" << A << endl;
    A[4] = 10;  // logic error (run-time), program may crash
    cout << A[4] << endl;

    // A[100] = 9;
    // cout << A[100] << endl;

    displayArray( A, 4 );

    B = new int [5];  // automatically allocated array
    cout << "B:" << B << endl;
    for ( int i = 0; i < 5; i++ )
        // B[i] = 2 * i + 1;
        *(B + i) =  2 * i + 1;  // equiavelent

//    B[100] = 999;            // run-time error
//     cout << B[100] << endl;

    displayArray( B, 5 );

    *(B + 3) *= 3; 
    displayArray( B, 5 );

    return 0;
}

