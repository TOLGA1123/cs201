#include <iostream>

using namespace std;

void displayArray( const double a[], const int size ) {
    for (size_t i = 0; i < size; i++)
    {
        cout << a[i] << " ";
    }
    cout << endl;
}

void shallow_copy1( double* arr, const int size, double*& output ) {
    output = arr;
}

void shallow_copy2( double* arr, const int size, double** output ) {
    *output = arr;
}

int main(int argc, char const *argv[])
{
    double d[] = {2.4, 5.3, 7.2};
    double *D;
    
    displayArray(d, 3);
    // shallow_copy1( d, 3, D );
    shallow_copy2( d, 3, &D );

    d[1] = -1;
    d[2] = -2;

    displayArray(D, 3); 
    displayArray(d, 3);

    return 0;
}

