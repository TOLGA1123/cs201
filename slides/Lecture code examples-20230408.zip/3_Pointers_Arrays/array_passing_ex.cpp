#include <iostream>

using namespace std;

// Write a function to initialize the
// array items with the value of C
void init( int* A, int size, int C ) {
   for ( int i = 0; i < size; i++ )
      A[i] = C;
}

void displayArray( const int a[], const int size ) {
// void displayArray( int* a, const int size ) {    
    for (size_t i = 0; i < size; i++)
    {
        cout << a[i] << " ";
    }
    cout << endl;    
}

int main(int argc, char const *argv[])
{
   int A1[ 40 ];
   int *A2 = new int [ 60 ];

   init( A1, 40, 10 );
   init( A2, 60, 100 );

   displayArray( A1, 40 );
   displayArray( A2, 60 );

   // Initialize the items in the
   // first half of the array with 1
   // and those in the second half
   // of the array with -1 
   init( A2, 30, 1 );
   init( A2 + 30, 30, -1 );

   displayArray( A2, 60 );

   delete [] A2;
  

    return 0;
}

