#include <iostream>

using namespace std;

int main() {
    int x = 4, y = 5, *a = &x, *b = a, **c = &b;
    cout << "Address of x: " << &x << endl;
    cout << "Address of y: " << &y << endl;
    cout << "Address of a: " << &a << endl;
    cout << "Address of b: " << &b << endl;
    cout << "Address of c: " << &c << endl;
    cout << "**c: " << **c << endl;
    cout << "*c : " << *c << endl;
    cout << "c  : " << c << endl;
    cout << "&c : " << &c << endl << endl;
    b = &y;
    *b = 3;
    cout << "**c: " << **c << endl;
    cout << "*c : " << *c << endl;
    cout << "c  : " << c << endl;
    cout << "&c : " << &c << endl << endl;
    cout << "*&c: " << *&c << endl;
    cout << "&*c: " << &*c << endl;
    cout << "*&x: " << *&x << endl;
    // cout << "&*x: " << &*x; 		compile-time error
    return 0;
}
