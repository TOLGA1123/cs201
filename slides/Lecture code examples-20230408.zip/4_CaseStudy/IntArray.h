#ifndef INTARRAY_H
#define INTARRAY_H

#include <iostream>

using namespace std;

class IntArray
{
public:
    // If a class has dynamically allocated data members, it is highly recommended to
    // re-implement the destructor and copy constructor, and overload the assignment
    // operator (instead of using the ones provided by the compiler)
    IntArray( const int = 0 );     			// constructor with a default argument
    IntArray( const IntArray& ); 		  	// copy constructor
    virtual ~IntArray();            				// destructor
    IntArray& operator=( const IntArray& );	// overloaded assignment operator
    int& operator[]( const int ); 		  	// overloaded subscript operator
private:
    int size;							// number of array items
    int* data;							// dynamically allocated array
// IntArray class declares the following two functions as its friend such that they
// can access its private data members and call its private member functions
    friend istream& operator>>( istream&, IntArray& );
    friend ostream& operator<<( ostream&, const IntArray& );
};
//istream& operator>>( istream&, IntArray& );
//ostream& operator<<( ostream&, const IntArray& );


#endif // INTARRAY_H
