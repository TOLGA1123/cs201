#include <iostream>

using namespace std;



class Test {
public:
   Test( int i = 0 ){
      id = i;
      cout << "Constructor " << id << endl;
   }
   ~Test(){
      cout << "Destructor " << id << endl;
   }
   Test( const Test& o ){
      id = o.id;
      cout << "Copy const " << id << endl;
   }
   Test& operator=( const Test& right ){
      id = right.id;
      cout << "Assignment " << id << endl;
      return *this;
   }
   int id;
};

int main() {
   cout << "checkpoint 1---" << endl;
   Test *b1;
   cout << "checkpoint 2---" << endl;
   b1 = new Test ( 100 );
   delete b1;
   cout << "checkpoint 3---" << endl;
   b1 = new Test [2];
   b1[0].id = 200;
   b1[1].id = 300;
   delete []b1;
   cout << "checkpoint 4---" << endl;
   b1 = new Test [2];
   b1[0].id = 400;
   b1[1].id = 500;
   delete b1;
   cout << "checkpoint 5---" << endl;
   return 0;
}

