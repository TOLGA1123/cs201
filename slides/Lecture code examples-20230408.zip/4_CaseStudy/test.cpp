#include <iostream>

using namespace std;

#include "IntArray.h"

int main1()
{
// Constructor call for a single
// dynamically created object
    IntArray* a1 = new IntArray ( 400 );
// Default constructor call for every
// object in the array
    IntArray* a2 = new IntArray [ 5 ];
// Destructor call for the single object
    delete a1; //
// Every object in the array receives a
// destructor call. If "delete a2;" is
// used, only the first object receives
// a destructor call
    delete [] a2;

    IntArray arr( 5 );
    cout << arr[ 3 ] << endl;	// used as an rvalue
    arr[ 3 ] = 10;	// used as an lvalue
    cout << arr[ 3 ] << endl;	// used as an rvalue

    cout << arr << endl;

    IntArray* p{new IntArray};

    int* greadesArray{ new int[10] };

    cout << "address of arr:" << &arr << endl;

    return 0;
}
