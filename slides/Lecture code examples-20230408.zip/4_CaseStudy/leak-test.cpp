// leak-test.cpp
#include <iostream>
using namespace std;
int main() {
  char* buf = new char[10];

  //  buf[9] = 'A';
  buf[100000] = 'A';

  cout << buf[100000] << endl;

  // buf[10] = 'B';

  //  buf[1000000] = 'A';
  //  delete [] buf;

  return 0;
}

/*
dijkstra{adayanik}:> g++ -Wall -g leak-test.cpp
dijkstra{adayanik}:>
dijkstra{adayanik}:>
dijkstra{adayanik}:> valgrind --leak-check=yes ./a.out
==12378== Memcheck, a memory error detector
==12378== Copyright (C) 2002-2009, and GNU GPL'd, by Julian Seward et al.
==12378== Using Valgrind-3.5.0 and LibVEX; rerun with -h for copyright info
==12378== Command: ./a.out
==12378==
==12378== Invalid write of size 1
==12378==    at 0x8048666: main (leak-test.cpp:7)
==12378==  Address 0x42c7032 is 0 bytes after a block of size 10 alloc'd
==12378==    at 0x4027084: operator new[](unsigned int) (vg_replace_malloc.c:258)
==12378==    by 0x804865C: main (leak-test.cpp:5)
==12378==
==12378==
==12378== HEAP SUMMARY:
==12378==     in use at exit: 10 bytes in 1 blocks
==12378==   total heap usage: 1 allocs, 0 frees, 10 bytes allocated
==12378==
==12378== 10 bytes in 1 blocks are definitely lost in loss record 1 of 1
==12378==    at 0x4027084: operator new[](unsigned int) (vg_replace_malloc.c:258)
==12378==    by 0x804865C: main (leak-test.cpp:5)
==12378==
==12378== LEAK SUMMARY:
==12378==    definitely lost: 10 bytes in 1 blocks
==12378==    indirectly lost: 0 bytes in 0 blocks
==12378==      possibly lost: 0 bytes in 0 blocks
==12378==    still reachable: 0 bytes in 0 blocks
==12378==         suppressed: 0 bytes in 0 blocks
==12378==
==12378== For counts of detected and suppressed errors, rerun with: -v
==12378== ERROR SUMMARY: 2 errors from 2 contexts (suppressed: 3 from 3)
dijkstra{adayanik}:>



dijkstra{adayanik}:> cat leak-test.cpp
#include <iostream>
using namespace std;

int main() {
  char *buf = new char[10];

  // buf[10] = 'A';
  buf[9] = 'A';

  delete [] buf;
  return 0;
}
dijkstra{adayanik}:>
dijkstra{adayanik}:>
dijkstra{adayanik}:> g++ -Wall -g leak-test.cpp
dijkstra{adayanik}:>
dijkstra{adayanik}:>
dijkstra{adayanik}:> valgrind --leak-check=yes ./a.out
==12421== Memcheck, a memory error detector
==12421== Copyright (C) 2002-2009, and GNU GPL'd, by Julian Seward et al.
==12421== Using Valgrind-3.5.0 and LibVEX; rerun with -h for copyright info
==12421== Command: ./a.out
==12421==
==12421==
==12421== HEAP SUMMARY:
==12421==     in use at exit: 0 bytes in 0 blocks
==12421==   total heap usage: 1 allocs, 1 frees, 10 bytes allocated
==12421==
==12421== All heap blocks were freed -- no leaks are possible
==12421==
==12421== For counts of detected and suppressed errors, rerun with: -v
==12421== ERROR SUMMARY: 0 errors from 0 contexts (suppressed: 3 from 3)
dijkstra{adayanik}:>

*/
