#include "IntArray.h"

// Constructor with a single integer
// parameter (this parameter has a
// default value set in the class
// definition such that it also serves
// as a default constructor)
IntArray::IntArray( const int aSize ) {
   if ( aSize <= 0) {
      size = 0;
      data = NULL;
   }
   else {
      size = aSize;
      data = new int[ size ];
      for ( int i = 0; i < size; i++ )
         data[ i ] = 0;
   }
   cout << "Constructor IntArray size " << size << endl;
}

// This copy constructor deep copies the
// array items as opposed to default copy
// constructor provided by the compiler
IntArray::IntArray( const IntArray& arr )
: size( arr.size ) {
    cout << "Copy constructor IntArray size " << size << endl;
   if ( size > 0 ) {
      data = new int [ size ];
      for ( int i = 0; i < size; i++ )
         data[ i ] = arr.data[ i ];
   }
   else
      data = NULL;
}


IntArray::~IntArray() {
    cout << "Destructor IntArray size " << size << endl;
   if ( data )
      delete [] data;
}

IntArray& IntArray::operator=( const IntArray& right ) {
    cout << "operator= IntArray size " << size << endl;
   if ( &right != this ) { // to avoid self-assignment
      if ( size != right.size ) {
         if ( size > 0 )
            delete [] data;
         size = right.size;
         if ( size > 0 )
            data = new int[ size ];
         else
            data = NULL;
      }
      for ( int i = 0; i < size; i++ )
         data[ i ] = right.data[ i ];
   }
   return *this; // to allow cascading
}

int& IntArray::operator[]( const int ind ){
   if (ind < 0 || ind >= size ){
      cout << "Error in indexing" << endl;
      exit(1);
   }
   else
      return data[ ind ];
}

istream& operator>>( istream& in, IntArray& arr ) {
   cout << "Enter " << arr.size << " integers: ";
   for ( int i = 0; i < arr.size; i++ )
      cin >> arr.data[ i ];
   return in;
}

ostream& operator<<( ostream& out, const IntArray& arr ) {
   for ( int i = 0; i < arr.size; i++ )
      cout << arr.data[ i ] << "\t";
   cout << endl;
   return out;
}


