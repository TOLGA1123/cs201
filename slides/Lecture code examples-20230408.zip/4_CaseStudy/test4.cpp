#include <iostream>

using namespace std;

class Test {
public:
   Test( int i = 0 ){
      id = i;
      cout << "Constructor " << id << endl;
   }
   ~Test(){
      cout << "Destructor " << id << endl;
   }
   Test( const Test& o ){
      id = o.id;
      cout << "Copy const " << id << endl;
   }
   Test& operator=( const Test& right ){
      id = right.id;
      cout << "Assignment " << id << endl;
      return *this;
   }
   int id;
};

void bar ( Test a, Test* b, Test& c ) {
   // ...
}
int main() {
   cout << "checkpoint 1---" << endl;
   Test  t1(11);
   Test& t2 = t1;
   Test  t3 = t1;
   t3.id = 33;
   cout << "checkpoint 2---" << endl;
   bar( t1, &t2, t3 );
   cout << "checkpoint 3---" << endl;
   Test* t4;
   Test* t5;
   t4 = &t1;
   t5 = t4;
   *t4 = t1;
   cout << "checkpoint 4---" << endl;
   bar( *t5, &t1, *t4 );
   cout << "checkpoint 5---" << endl;
   return 0;
}
