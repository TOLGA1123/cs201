#include <iostream>

using namespace std;



class Test {
public:
   Test( int i = 0 ){
      id = i;
      cout << "Constructor " << id << endl;
   }
   ~Test(){
      cout << "Destructor " << id << endl;
   }
   Test( const Test& o ){
      id = o.id;
      cout << "Copy const " << id << endl;
   }
   Test& operator=( const Test& right ){
      id = right.id;
      cout << "Assignment " << id << endl;
      return *this;
   }
   int id;
};


Test t1( 10 );
Test t2( 20 );

void foo( bool flag ){
   Test t3( 30 );
   static Test t4( 40 );

   if ( flag ){
      Test t5( 50 );
      Test t6( 60 );
   }
   Test t7( 70 );
}
int main() {
   cout << "checkpoint 1---" << endl;
   Test t8( 80 );
   cout << "checkpoint 2---" << endl;
   foo( false );
   cout << "checkpoint 3---" << endl;
   foo( true );
   cout << "checkpoint 4---" << endl;
   return 0;
}
