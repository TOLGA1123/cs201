// show the importance of break statements by removing break in case 8
// and running the program for input case 80 (output will be C, not B!)
#include <iostream>

using namespace std;

int main() {
    int grade;
    char letter;

    cin >> grade;
    if ( grade < 0 || grade > 100 )
        cout << "Invalid grade\n";
    else {
        switch ( grade / 10 ) {
        case 10:
        case 9: letter = 'A'; break;
        case 8: letter = 'B'; break;
        case 7: letter = 'C'; break;
        case 6: letter = 'D'; break;
        default: letter = 'F'; break;
        }
        cout << "Your letter grade is " << letter << endl;
    }

    return 0;
}
