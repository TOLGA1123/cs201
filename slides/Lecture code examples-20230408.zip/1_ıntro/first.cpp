#include <iostream>

int main() {
    int cno;

    cout << "enter course number:";   // insertion operator
    cin >> cno;  // extraction operator
    std::cout << "Welcome to CS " << cno << std::endl;
    return 0;
}
