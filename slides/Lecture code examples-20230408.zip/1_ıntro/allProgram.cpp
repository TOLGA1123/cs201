class GradeBook {
public:
    GradeBook(int no = 100) {
	// courseNo = no;
	setCourseNo(no);
	cout << "in constructor.." << endl;
    }
    // GradeBook() {
    // 	courseNo = 0;
    // 	cout << "in default constructor.." << endl;
    // }

    void setCourseNo(int cno) {
	if ( cno >= 100 && cno <= 999 )
	    courseNo = cno;
	else {
	    cout << "invalid course no" << endl;
	    courseNo = 0;
	}
    }
    
    void displayMessage(int cno) {
	cout << "Welcome to CS " << cno << endl;
    }
    void displayMessage() {
	cout << "Welcome to CS " << courseNo << endl;
    }
private:
    int courseNo;
};

int main() {
    int cno;
    GradeBook g1, g2(202);  // objects (not references)
    //    g1.displayMessage(202);
    g1.displayMessage();
    g2.displayMessage();

    // cout << "enter course number:";   // insertion operator
    // cin >> cno;  // extraction operator

    cout << "size of int:" << sizeof(int) << endl;
    cout << "size of cno:" << sizeof(cno) << endl;
    cout << "size of double:" << sizeof(double) << endl;
    cout << "size of g1:" << sizeof(g1) << endl;
    cout << "size of short int:" << sizeof(short int) << endl;

    return 0;
}
