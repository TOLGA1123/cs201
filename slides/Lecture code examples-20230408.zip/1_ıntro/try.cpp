// examples for slide 20 and slide 24
include <iostream>

using namespace std;

int main() {
    int x = -4;

    // if (x)                                                                   
    if (x = 0)
        cout << "true" << endl;
    else
        cout << "false" << endl;

    cout << "x after if: " << x << endl;

#include <iostream>

using namespace std;

int main() {
    int x = -4;

    // if (x)                                                                   
    if (x = 0)
	cout << "true" << endl;
    else
        cout << "false" << endl;

    cout << "x after if: " << x << endl;

    // try changing "break" to "continue"
    for ( int i = 1; i <= 5; i++ ) {
        if ( i == 3 )
            break;
        cout << i << endl;
    }
    cout << "done" << endl;

    return 0;
}

