#include <iostream>
using namespace std;

class Book{
public:
   void setNo( int i );
   int getNo( ) const;
   void displayNo( );
   int publicNo;    
private:
   int no;
};

void Book::setNo( int n ){
    no = n;
}

int Book::getNo( ) const{
    return no;
}

void Book::displayNo( ){
    cout << no << endl;    
}

/* ostream& operator<<( ostream& out, const MyClass& myObject ) {
    // statements such as:
    // out << "[MyClass] property:" << myObject.getProperty();
    return out;
} */

void foo( const Book& B ){
   // B is a constant reference, thus it CANNOT change 
   // a data member or call a non-const member function

   // THREE STATEMENTS BELOW LEAD TO COMPILE-TIME ERRORS
   // B.publicNo = 10;
   // B.setNo(20);
   B.displayNo();
   cout << B.getNo() << endl;
}

int main() {
    Book A;
    foo( A );
    // cout << "A is " << A << "***" << endl;
    return 0;
}
