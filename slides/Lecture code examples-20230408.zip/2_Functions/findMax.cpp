#include <iostream>
using namespace std;

int findMax( int x, int y ) {
   if ( x > y )
      return x;
   else
      return y;
}

int main() {
   int larger = findMax( 42, 16 );
   cout << "The larger of 42 and 16 is " << larger << endl;
   return 0;
}

