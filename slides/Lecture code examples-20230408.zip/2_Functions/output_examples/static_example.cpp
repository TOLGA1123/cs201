#include <iostream>
using namespace std;

void g1()
{
    int a = 4;
    cout << a << endl;
    a++;
}

void g2()
{
    static int b = 4;
    cout << b << endl;
    b++;
}

int main() {
    g1();
    g1();
    g2();
    g2();
    // cout << a;   // compile-time error
    // cout << b;   // compile-time error
    return 0;
}
