#include <iostream>
using namespace std;

void f1() {
    int k = 10;
    cout << k << endl;
    k++;
    if ( k > 5 ) {
        int a = 50;
        cout << a << endl;
        k++;
    }
    cout << k << endl;
}

int main() {
    int k = 20;
    cout << k << endl;
    k++;
    f1();
    cout << k << endl;
    return 0;
}
