#ifndef __MAX_H
#define __MAX_H
template < typename T >
T maximum( T num1, T num2 ) {
   if ( num1 > num2 )
      return  num1;
   else
      return num2;
}
#endif
