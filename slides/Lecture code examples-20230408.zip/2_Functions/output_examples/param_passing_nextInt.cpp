#include <iostream>

using namespace std;

void nextInt( int );
void nextIntByRef( int& );

int main() {
    int x = 0;

    cout << "Pass-by-value demo:" << endl;
    cout  <<"x before calling nextInt: " << x << endl;
    nextInt( x );
    cout  <<"x after calling nextInt: " << x << endl;

    cout << endl;

    cout << "Pass-by-value demo:" << endl;
    cout  <<"x before calling nextIntByRef: " << x << endl;
    nextIntByRef( x );
    cout  <<"x after calling nextIntByRef: " << x << endl;

    return 0;
}

void nextInt( int x ) {
    x++;
}

void nextIntByRef( int& x) {
    x++;
}
