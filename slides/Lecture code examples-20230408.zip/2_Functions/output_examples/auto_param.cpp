#include <iostream>
using namespace std;

// auto parameter is not a good idea for now, so you should avoid it

void f(auto p) {
    cout << "p is " << p << endl;
}

int main() {

    f(10);
    f(22.4);
    f1("abc");

    return 0;
}
