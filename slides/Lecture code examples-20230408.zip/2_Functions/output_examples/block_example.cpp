#include <iostream>
using namespace std;


int main() {

    int x = 2;

    cout << x;
    // test 1
    {
        int x = 3;
        cout << x;
    }

    // test 2
    {
        int x = 4;
        cout << x;
        {
            int x = 5;
            cout << x;  
        }
        cout << x;
    }
    cout << x;
}