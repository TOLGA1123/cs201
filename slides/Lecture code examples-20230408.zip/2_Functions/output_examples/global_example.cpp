#include <iostream>
using namespace std;

int k = 4;

void f() {
    cout << k;
    k = 7;
}
void g() {
    cout << k;
    k++;
}
void h() {
    int k = 1;
    cout << k;
    k = 20;
}

int main() {
    cout << k;
    f();
    cout << k;
    g();
    cout << k;
    h();
    cout << k;
    return 0;
}
