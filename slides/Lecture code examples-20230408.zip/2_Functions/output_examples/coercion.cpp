#include <iostream>

using std::cout;
using std::endl;
using std::cin;

int cube( int );

int main()
{
    double d = 4.7;

    cout << "\ncube(" << d << ") = " << cube( d ) << endl;
    cout << "d = " << d << endl;
    return 0;
}

int cube( int x )
{
    return x * x *x;
}
