#include <iostream>
#include <string>
using namespace std;

#include "max.h"

int main() {
   cout << "The maximum of 5 and 3: ";
   cout  << maximum( 5, 3 ) << endl;
    
   double a = 4.5;
   cout << "The maximum of a and 5.6: ";
   cout  << maximum( a, 5.6 ) << endl;

   string s1 = "Hello", s2 = "World";
   cout << "The maximum of s1 and s2: ";
   cout  << maximum( s1, s2 ) << endl;

   // compile time error
   // cout  << maximum( a, 5 ) << endl;
   return 0;
}
