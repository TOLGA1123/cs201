#include <iostream>

using namespace std;


// use principle of least privilege
void computeSumProduct( ? x, ? int y, ? sum, ? product ){
   sum = x + y;
   product = x * y;    
}

int main(){
   int s, p, c = 10;
   double r, t = 3.2;

   cout << "sum and product: " << s << " " << p << endl;

   // computeSumProduct( ?, ?, ?, ? );

   return 0;
}

