#include <iostream>

using namespace std;

void foo(int x) {
    x *= 2;
}

void bar(int& x) {
    x *= 4;
}

int main() {
    int count;
    int& refCount = count;   // reference to int (read it right to left)
    
    count = 4;
    cout << "count: " << count << endl;
    cout << "refCount: " << refCount << endl;    

    refCount = 8;
    cout << "count: " << count << endl;
    cout << "refCount: " << refCount << endl;    

    count = 4;
    cout << "count before foo: " << count << endl;
    foo(count);
    cout << "count after foo: " << count << endl;

    count = 4;
    cout << "count before bar: " << count << endl;
    bar(count);
    cout << "count after bar: " << count << endl;

    return 0;
}

